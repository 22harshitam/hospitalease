"""
Database configuration and connection management for HospitalEasy
"""
import os
import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2.pool import SimpleConnectionPool
from datetime import datetime
import hashlib
from werkzeug.security import generate_password_hash

class DatabaseManager:
    def __init__(self):
        self.pool = None
        self.init_connection_pool()
    
    def init_connection_pool(self):
        """Initialize PostgreSQL connection pool"""
        try:
            self.pool = SimpleConnectionPool(
                minconn=1,
                maxconn=10,
                host=os.getenv('DB_HOST', 'localhost'),
                database=os.getenv('DB_NAME', 'hospitaleasy'),
                user=os.getenv('DB_USER', 'postgres'),
                password=os.getenv('DB_PASSWORD', 'password'),
                port=os.getenv('DB_PORT', '5432')
            )
            print("✅ PostgreSQL connection pool created successfully")
        except Exception as e:
            print(f"❌ Failed to connect to PostgreSQL: {e}")
            self.pool = None
    
    def get_connection(self):
        """Get a connection from the pool"""
        if self.pool:
            return self.pool.getconn()
        else:
            raise Exception("Database connection pool not initialized")
    
    def release_connection(self, conn):
        """Release a connection back to the pool"""
        if self.pool and conn:
            self.pool.putconn(conn)
    
    def execute_query(self, query, params=None, fetch_all=True):
        """Execute a query and return results"""
        conn = None
        try:
            conn = self.get_connection()
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(query, params)
                if fetch_all:
                    result = cursor.fetchall()
                else:
                    result = cursor.fetchone()
                conn.commit()
                return result
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if conn:
                self.release_connection(conn)
    
    def execute_insert(self, query, params=None):
        """Execute an insert query and return the inserted ID"""
        conn = None
        try:
            conn = self.get_connection()
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(query, params)
                result = cursor.fetchone()
                conn.commit()
                return result
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if conn:
                self.release_connection(conn)
    
    def execute_update(self, query, params=None):
        """Execute an update/delete query"""
        conn = None
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                conn.commit()
                return cursor.rowcount
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if conn:
                self.release_connection(conn)

# Database operations for each table
class DoctorsDB:
    def __init__(self, db_manager):
        self.db = db_manager
    
    def get_all_doctors(self):
        """Get all doctors"""
        query = "SELECT * FROM doctors ORDER BY name"
        return self.db.execute_query(query)
    
    def get_doctor_by_id(self, doctor_id):
        """Get doctor by ID"""
        query = "SELECT * FROM doctors WHERE id = %s"
        return self.db.execute_query(query, (doctor_id,), fetch_all=False)
    
    def get_doctor_by_email(self, email):
        """Get doctor by email"""
        query = "SELECT * FROM doctors WHERE email = %s"
        return self.db.execute_query(query, (email,), fetch_all=False)
    
    def create_doctor(self, name, email, specialization, password, **kwargs):
        """Create a new doctor"""
        password_hash = generate_password_hash(password)
        query = """
        INSERT INTO doctors (name, email, specialization, password_hash, rating, reviews, 
                            experience, image_url, is_available, biography, consultation_fee)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id
        """
        params = (
            name, email, specialization, password_hash,
            kwargs.get('rating', 0.0),
            kwargs.get('reviews', 0),
            kwargs.get('experience', ''),
            kwargs.get('image_url', ''),
            kwargs.get('is_available', True),
            kwargs.get('biography', ''),
            kwargs.get('consultation_fee', 0.0)
        )
        return self.db.execute_insert(query, params)

class PatientsDB:
    def __init__(self, db_manager):
        self.db = db_manager
    
    def get_patient_by_email(self, email):
        """Get patient by email"""
        query = "SELECT * FROM patients WHERE email = %s"
        return self.db.execute_query(query, (email,), fetch_all=False)
    
    def create_patient(self, name, email, phone, age, password, **kwargs):
        """Create a new patient"""
        # Simple password hash using SHA-256
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        query = """
        INSERT INTO patients (name, email, phone, age, password_hash, address, 
                            emergency_contact, blood_group)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id
        """
        params = (
            name, email, phone, age, password_hash,
            kwargs.get('address', ''),
            kwargs.get('emergency_contact', ''),
            kwargs.get('blood_group', '')
        )
        return self.db.execute_insert(query, params)

class AppointmentsDB:
    def __init__(self, db_manager):
        self.db = db_manager
    
    def get_all_appointments(self, doctor_id=None, status=None):
        """Get all appointments, filtered by doctor_id and/or status"""
        query = """
        SELECT a.*, d.name as doctor_name, d.specialization as doctor_specialization,
               p.name as patient_name, p.age as patient_age, p.phone as patient_phone
        FROM appointments a
        LEFT JOIN doctors d ON a.doctor_id = d.id
        LEFT JOIN patients p ON a.patient_id = p.id
        WHERE 1=1
        """
        params = []
        
        if doctor_id:
            query += " AND a.doctor_id = %s"
            params.append(doctor_id)
        
        if status:
            query += " AND a.status = %s"
            params.append(status)
        
        query += " ORDER BY a.appointment_date DESC, a.time_slot"
        
        return self.db.execute_query(query, params)
    
    def get_appointment_by_id(self, appointment_id):
        """Get appointment by ID"""
        query = """
        SELECT a.*, d.name as doctor_name, d.specialization as doctor_specialization,
               p.name as patient_name, p.age as patient_age, p.phone as patient_phone
        FROM appointments a
        LEFT JOIN doctors d ON a.doctor_id = d.id
        LEFT JOIN patients p ON a.patient_id = p.id
        WHERE a.id = %s
        """
        return self.db.execute_query(query, (appointment_id,), fetch_all=False)
    
    def create_appointment(self, doctor_id, patient_id, appointment_date, time_slot, 
                          symptoms, token, consultation_fee, **kwargs):
        """Create a new appointment"""
        query = """
        INSERT INTO appointments (doctor_id, patient_id, appointment_date, time_slot, 
                                symptoms, token, consultation_fee, id_file_path, photo_path)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id
        """
        params = (
            doctor_id, patient_id, appointment_date, time_slot,
            symptoms, token, consultation_fee,
            kwargs.get('id_file_path'),
            kwargs.get('photo_path')
        )
        return self.db.execute_insert(query, params)
    
    def update_appointment_status(self, appointment_id, status):
        """Update appointment status"""
        query = "UPDATE appointments SET status = %s WHERE id = %s"
        return self.db.execute_update(query, (status, appointment_id))
    
    def cancel_appointment(self, appointment_id):
        """Cancel an appointment"""
        return self.update_appointment_status(appointment_id, 'Cancelled')

# Initialize database manager and table classes
db_manager = DatabaseManager()
doctors_db = DoctorsDB(db_manager)
patients_db = PatientsDB(db_manager)
appointments_db = AppointmentsDB(db_manager)
